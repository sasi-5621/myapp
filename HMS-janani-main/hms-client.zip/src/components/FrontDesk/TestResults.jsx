import React, { useState } from "react";
import "./TestResults.css";
import Navbar from "./Navbar";

const TestResults = () => {
  const [dropdownStates, setDropdownStates] = useState(Array(10).fill(false)); // Assuming you have 10 dropdowns
  const dropdownLabels = [
    "HAEMATOLOGY",
    "BIO CHEMISTRY",
    "LIPID PROFILE",
    "KIDNEY FUNCTION TEST",
    "LIVER FUNCTION TEST",
    "UACR",
    "URINE ROUTINE",
    "THYROID FUNCTION TEST",
    "PCOS/ Hirsutism Profile/ Infertiity Profile",
    "Others",
  ];

  const toggleDropdown = (index) => {
    const newDropdownStates = [...dropdownStates];
    newDropdownStates[index] = !newDropdownStates[index];
    setDropdownStates(newDropdownStates);
  };

  const handleCommonTestsClick = () => {
    console.log("Common tests button clicked");
  };

  const handleAdditionalTestsClick = () => {
    console.log("Additional Test button clicked");
  };

  return (
    <>
    <Navbar />
    <div>
      <div className="navbar_65">
        <div className="navbar-left">
          <button className="navbar-button" onClick={handleCommonTestsClick}>
            Common tests
          </button>{" "}
          &nbsp;&nbsp;&nbsp;
          <button
            className="navbar-button"
            onClick={handleAdditionalTestsClick}
          >
            Additional Test
          </button>
        </div>
        <div className="navbar-middle">
          <span className="patient-name">Patient Name: Chandarakanth</span>
        </div>
        <div className="navbar-right">
          <label htmlFor="auto-calendar">Auto Calendar</label>&nbsp;&nbsp;
          <label className="switch">
            <input type="checkbox" />
            <span className="slider_12 round"></span>
          </label>
          &nbsp;&nbsp;
          <button className="save-button">Save</button>&nbsp;&nbsp;
        </div>
      </div>
      <div className="search-bar-container">
        <input type="text" placeholder="Search..." className="search-bar" />
        <button className="add-date-button">Add Date</button>
      </div>
      <div className="droupdownmainven">
        <div className="droupdownsven">
          {dropdownLabels.map((label, index) => (
            <div
              key={index}
              className="droupdownstoggleven"
              onClick={() => toggleDropdown(index)}
            >
              {label}
              <hr />
              {dropdownStates[index] && (
                <div className="dropdown-contentven">
                  <div>hi</div>
                  <hr />
                  <div>hi</div>
                  <hr />
                  <div>hi</div>
                  <hr />
                  <div>hi</div>
                  <hr />
                  <div>hi</div>
                  <hr />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
    </>
  );
};

export default TestResults;
