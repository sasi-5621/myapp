import React, { useState } from 'react';
import './attachment.css'; // Import your CSS file for styling\
import Navbar from './Navbar';

const Attachment = () => {
  const [popupVisible, setPopupVisible] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]); // To track uploaded files
  const [fileInputs, setFileInputs] = useState([0]); // To dynamically generate file input fields

  const filesToUpload = [
    'File 1',
    'File 2',
    'File 3',
    'File 4',
    'File 5',
    'File 6',
    'File 7',
    'File 8',
    'File 9',
    'File 10',
    'File 11',
    'File 12'
    
  ];

  const handleOpenPopup = () => {
    setPopupVisible(true);
  };

  const handleClosePopup = () => {
    setUploadedFiles([]); 
    setFileInputs([0]); 
    setPopupVisible(false);
  };

  const handleFileUpload = (index, file) => {
    // Handle the file upload logic here
    setUploadedFiles((prevUploadedFiles) => {
      const newUploadedFiles = [...prevUploadedFiles];
      newUploadedFiles[index] = file;
      return newUploadedFiles;
    });

    if (index === fileInputs[fileInputs.length - 1]) {
      setFileInputs([...fileInputs, index + 1]); 
    }
  };

  return (
    <>
    <Navbar />
    <div className='AttFront'>
      <h1>Front Desk</h1>
      <button onClick={handleOpenPopup}>Attachments</button>

      {popupVisible && (
        <div className="attachments-overlay_65">
          <div className="popup">
            <div className="popup-header">
              <h2 className="attachments-title">Attachments</h2>
              <button className="popup-close-button" onClick={handleClosePopup}>
                X
              </button>
            </div>
            <hr />
            <div className="attachments-content">
              <div className="popup-scrollable-content">
                {fileInputs.map((inputIndex) => (
                  <div key={inputIndex}>
                    <p>Updating file: {filesToUpload[inputIndex]}</p>
                    <input
                      className='attachment'
                      type="file"
                      onChange={(e) => handleFileUpload(inputIndex, e.target.files[0])}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
    </>
  );
};

export default Attachment;