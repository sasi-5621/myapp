import React from 'react';
import './prescription.css';
import { GiCaduceus } from 'react-icons/gi';
import Navbar from './Navbar';

const Prescription = () => {
  return (
    <>
    <Navbar />
    <div className="prescription-container">
      <div className="doctor-details">
        <div className="doctor-info_pavan">
          <div>
            <h1 className='icon'><GiCaduceus /><span className="ttp">Janani Clinic</span></h1>
            <div className='doct'>
              <p><strong>Doctor Name:</strong> DR.Jali Reddy</p>
              <p>MBBS,<br />General Physician</p>
              <p><strong>Add:</strong> Bangalore, RR nagar</p>
              <p><strong>Mobile:</strong> +91-91-602-519-46</p>
            </div>
          </div>
        </div>
      </div>

      <hr style={{ height: '3px', backgroundColor: 'black', border: 'none' }} />
      <div className='main-heading-10' style={{ backgroundColor: '#d2cfcf' }}>
        <div className="patient-section">
          <hr />
          <p><strong>Name:</strong> Shiva Krishna</p>
          <p><strong>ID:</strong> 01</p>
          <p><strong>Phone:</strong> +91-70-751-162-46</p>
        </div>
        <div className='pv-10'>
          <p><strong>Date:</strong> 26-08-2023</p>
          <p><strong>#visit:</strong> 01</p>
        </div>
      </div>
      <br />
      <hr style={{ height: '2px', backgroundColor: 'black', border: 'none' }} />
      <p><strong>Height:</strong> 165 cm</p>
      <p><strong>Complaints:</strong> Fever, Cough</p>
      <p><strong>Diagnosis:</strong> Viral fever</p>

      <div className="medicine-section">
        <table>
          <thead>
            <tr>
              <th>MEDICINE</th>
              <th>DOSE</th>
              <th>TIMING-FREQ-DURATION</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Tab.Dolo.650mg</td>
              <td>1-0-1</td>
              <td>2 times a day</td>
            </tr>
            <tr>
              <td>Tab.Azee 250mg</td>
              <td>0-1-0</td>
              <td>once daily</td>
            </tr>
            <tr>
              <td>Tab.Pain 40</td>
              <td>1-1-0</td>
              <td>2 times a day</td>
            </tr>
            {/* Add more medicines here */}
          </tbody>
        </table>

      <hr style={{ height: '2px', backgroundColor: 'black', border: 'none' }} />
          <p><strong>Next Visit:</strong> 28-Sep-2023</p>

      </div>
    </div>
    </>
  );
};

export default Prescription;