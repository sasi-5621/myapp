const DoctorComplaints = require('../models/DoctorComplaints');

// Create a new DoctorComplaints record
exports.createComplaints = async (req, res) => {
  try {
    const {
      DoctorComplaints,
      diagnosis,
      medicine,
      advice,
      dietexercise,
      testsRequested,
      testWhen,
      nextVisit,
      nextVisitType,
      nextVisitDate,
    } = req.body;

    const newComplaints = new DoctorComplaints({
      DoctorComplaints: DoctorComplaints,
      diagnosis: diagnosis,
      medicine: medicine,
      advice: advice,
      dietexercise: dietexercise,
      testsRequested: testsRequested,
      testWhen: testWhen,
      nextVisit: nextVisit,
      nextVisitType: nextVisitType,
      nextVisitDate: nextVisitDate,
    });

    await newComplaints.save();

    res.status(201).json({ message: 'DoctorComplaints saved successfully' });
  } catch (error) {
    console.error('Error while saving DoctorComplaints:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get all DoctorComplaints records
exports.getAllComplaints = async (req, res) => {
  try {
    const DoctorComplaints = await DoctorComplaints.find();
    res.status(200).json(DoctorComplaints);
  } catch (error) {
    console.error('Error fetching DoctorComplaints:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
