// controllers/pharmacyController.js
const Medicine = require('../models/MedicineModel');
const PurchaseOrder = require('../models/PurchaseOrderModel');

// Add Medicine
exports.addMedicine = async (req, res) => {
  try {
    const newMedicine = new Medicine({
     // Medicine: req.body.Medicine,
      // unitstrips: req.body.unitstrips,
      // NoOfStrips: req.body.NoOfStrips,
      stockListName: req.body.stockListName,
      date: req.body.date,
    });

    await newMedicine.save();

    res.status(200).json({ message: 'Medicine added successfully' });
  } catch (error) {
    console.error('Error adding medicine:', error);
    res.status(500).json({ error: 'An error occurred while adding medicine. Please try again later.' });
  }
};

// Add Create Purchase Order
exports.addCreatePurchaseOrder = async (req, res) => {
  try {
    const newCreatePurchaseOrder = new PurchaseOrder({
      id: req.body.id,
      stockListName: req.body.stockListName,
      date: req.body.date, // Updated the ID to a string
      Medicine: req.body.Medicine, // Updated field name to match frontend
      unitstrips: req.body.unitstrips, // Updated field name to match frontend
      NoOfStrips: req.body.NoOfStrips, // Updated field name to match frontend
      Edit: req.body.Edit, // Updated field name to match frontend
    });

    await newCreatePurchaseOrder.save();

    res.status(201).json(newCreatePurchaseOrder);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to add CreatePurchaseOrder' });
  }
};

// Get Create Purchase Orders
exports.getCreatePurchaseOrders = async (req, res) => {
  try {
    const createPurchaseOrders = await PurchaseOrder.find();
    res.status(200).json(createPurchaseOrders);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch CreatePurchaseOrders' });
  }
};

// Update Create Purchase Order
exports.updateCreatePurchaseOrder = async (req, res) => {
  try {
    // Implement your update logic here based on the provided ID
    // You can use req.params.id to get the ID from the URL
    // Then update the corresponding purchase order and return the updated data
    // Example:
    // const updatedPurchaseOrder = await PurchaseOrder.findByIdAndUpdate(req.params.id, req.body, { new: true });

    // Replace the above example with your specific update logic

    res.status(200).json({ message: 'Purchase Order updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to update CreatePurchaseOrder' });
  }
};

// Delete Create Purchase Order
exports.deleteCreatePurchaseOrder = async (req, res) => {
  try {
    const purchaseOrderId = req.params.id;

    const deletedPurchaseOrder = await PurchaseOrder.findByIdAndDelete(purchaseOrderId);
    if (!deletedPurchaseOrder) {
      return res.status(404).json({ error: 'Purchase Order not found' });
    }

    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Error deleting CreatePurchaseOrder' });
  }
};
