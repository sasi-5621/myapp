// controllers/invoiceController.js
const Invoice = require('../models/InvoiceModel');

exports.addInvoice = async (req, res) => {
  try {
    const newInvoice = new Invoice(req.body);
    await newInvoice.save();
    res.status(201).json(newInvoice);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to add invoice' });
  }
};

exports.getInvoice = async (req, res) => {
  try {
    const invoices = await Invoice.find();
    res.status(200).json(invoices);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch invoices' });
  }
};

exports.deleteInvoice = async (req, res) => {
  const invoiceId = req.params.id;

  try {
    const deletedInvoice = await Invoice.findByIdAndDelete(invoiceId);
    if (!deletedInvoice) {
      return res.status(404).json({ error: 'Invoice not found' });
    }
    res.status(204).end();
  } catch (error) {
    console.error(error);
    res.status(400).json({ error: 'Error deleting invoice' });
  }
};
