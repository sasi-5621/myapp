// controllers/vitalsController.js
const Vitals = require('../models/VitalsModel');

exports.createVitals = async (req, res) => {
  const VitalsData = req.body;
  try {
    const newVitals = new Vitals(VitalsData);

    await newVitals.save();

    res.status(200).json({ message: 'Vitals created successfully.' });
  } catch (error) {
    console.error('Error creating Vitals:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getVitals = async (req, res) => {
  try {
    const Vitals = await Vitals.find();
    res.status(200).json(Vitals);
  } catch (error) {
    console.error('Error fetching Vitals:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
