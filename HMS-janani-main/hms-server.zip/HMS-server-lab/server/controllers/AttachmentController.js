// controllers/fileController.js
const File = require('../models/Attachment');

exports.uploadFile = (req, res) => {
  console.log('File uploaded:', req.file);
  res.status(200).json({ message: 'File uploaded successfully.' });
};

exports.saveFileInfo = async (req, res) => {
  const { index, filename } = req.body;
  console.log(`Save file ${index}`);

  try {
    const newFile = new File({
      filename: filename,
    });

    await newFile.save();

    res.status(200).json({ message: 'File information saved successfully.' });
  } catch (error) {
    console.error('Error saving file information:', error);
    res.status(500).json({ message: 'Error saving file information.' });
  }
};
