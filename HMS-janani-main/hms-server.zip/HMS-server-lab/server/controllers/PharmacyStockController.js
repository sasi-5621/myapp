const Pharmacy = require('../models/PharmacyStockModel');

// Handle the PUT request to update a property
exports.updateProperty = async (req, res) => {
  const id = req.params.id;
  const propertyData = req.body;

  try {
    const updatedProperty = await Pharmacy.findOneAndUpdate(
      { _id: id },
      propertyData,
      { new: true }
    );
    if (updatedProperty) {
      res.status(200).json({ message: 'Property updated successfully.', updatedProperty });
    } else {
      res.status(404).json({ error: 'Property not found.' });
    }
  } catch (error) {
    console.error('Error updating property:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

// Handle the GET request to fetch properties
exports.getProperties = async (req, res) => {
  try {
    const properties = await Pharmacy.find();
    res.status(200).json(properties);
  } catch (error) {
    console.error('Error fetching properties:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
