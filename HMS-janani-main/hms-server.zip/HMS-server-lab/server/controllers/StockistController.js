const Stockist = require('../models/StockistModel');

// Handle the GET request to fetch stockist data
exports.getStockists = async (req, res) => {
  try {
    const stockists = await Stockist.find();
    res.status(200).json(stockists);
  } catch (error) {
    console.error('Error fetching stockists:', error);
    res.status(500).json({ error: 'An error occurred while fetching data' });
  }
};

// Handle the PUT request to update a stockist
exports.updateStockist = async (req, res) => {
  const stockistId = req.params.id;
  const updatedStockistData = req.body;

  try {
    const updatedStockist = await Stockist.findByIdAndUpdate(stockistId, updatedStockistData, { new: true });
    res.status(200).json(updatedStockist);
  } catch (error) {
    console.error('Error updating stockist:', error);
    res.status(500).json({ error: 'An error occurred while updating the stockist' });
  }
};
