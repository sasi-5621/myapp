// controllers/pharmacyController.js
const Inventory = require('../models/InventoryModel');

exports.createInventoryItem = async (req, res) => {
  try {
    const newItem = new Inventory({
      medicinename: req.body.medicinename,
      remainingunits: req.body.remainingunits,
      expirydate: req.body.expirydate,
    });

    await newItem.save();

    res.status(200).json({ message: 'Inventory item created successfully.' });
  } catch (error) {
    console.error('Error creating inventory item:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getInventoryItems = async (req, res) => {
  try {
    const inventoryItems = await Inventory.find();
    res.status(200).json(inventoryItems);
  } catch (error) {
    console.error('Error fetching inventory items:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getExpiryInventoryItems = async (req, res) => {
  const currentDate = new Date();

  try {
    const expiryInventoryItems = await Inventory.find({ expirydate: { $lt: currentDate } });
    res.status(200).json(expiryInventoryItems);
  } catch (error) {
    console.error('Error fetching expiry inventory items:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getLowInventoryItems = async (req, res) => {
  try {
    const lowInventoryItems = await Inventory.find({ remainingunits: { $lt: 10 } });
    res.status(200).json(lowInventoryItems);
  } catch (error) {
    console.error('Error fetching low inventory items:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getZeroInventoryItems = async (req, res) => {
  try {
    const zeroInventoryItems = await Inventory.find({ remainingunits: 0 });
    res.status(200).json(zeroInventoryItems);
  } catch (error) {
    console.error('Error fetching zero inventory items:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
