const CreatePurchaseOrder = require('../models/CreatePurchaseOrderModel');

// Create a new purchase order
exports.createPurchaseOrder = async (req, res) => {
  try {
    const newPurchaseOrder = new CreatePurchaseOrder(req.body);
    await newPurchaseOrder.save();
    res.status(201).json({ message: 'Purchase order created successfully' });
  } catch (error) {
    console.error('Error creating purchase order:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get all purchase orders
exports.getAllPurchaseOrders = async (req, res) => {
  try {
    const purchaseOrders = await CreatePurchaseOrder.find();
    res.json(purchaseOrders);
  } catch (error) {
    console.error('Error fetching purchase orders:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get purchase order by ID
exports.getPurchaseOrderById = async (req, res) => {
  const { id } = req.params;
  try {
    const purchaseOrder = await CreatePurchaseOrder.findById(id);
    if (!purchaseOrder) {
      return res.status(404).json({ error: 'Purchase order not found' });
    }
    res.json(purchaseOrder);
  } catch (error) {
    console.error('Error fetching purchase order by ID:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update purchase order by ID
exports.updatePurchaseOrderById = async (req, res) => {
  const { id } = req.params;
  const updatedData = req.body;

  try {
    const updatedPurchaseOrder = await CreatePurchaseOrder.findByIdAndUpdate(
      id,
      updatedData,
      { new: true }
    );

    if (!updatedPurchaseOrder) {
      return res.status(404).json({ error: 'Purchase order not found' });
    }

    res.json({ message: 'Purchase order updated successfully' });
  } catch (error) {
    console.error('Error updating purchase order:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Delete purchase order by ID
exports.deletePurchaseOrderById = async (req, res) => {
  const { id } = req.params;

  try {
    const deletedPurchaseOrder = await CreatePurchaseOrder.findByIdAndDelete(id);
    if (!deletedPurchaseOrder) {
      return res.status(404).json({ error: 'Purchase order not found' });
    }
    res.json({ message: 'Purchase order deleted successfully' });
  } catch (error) {
    console.error('Error deleting purchase order:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
