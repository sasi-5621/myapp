// controllers/medicineController.js
const MedicineList = require('../models/MedicineListModel');

exports.createMedicine = async (req, res) => {
  const medicineData = req.body;

  try {
    // Check if stock is below 50 and set stockalert property accordingly
    if (medicineData.stock < 50) {
      medicineData.stockalert = 'true';
      // Here, you can also send a message to the supplier
      // You can use a messaging service or send an email to the supplier
    } else {
      medicineData.stockalert = 'false';
    }

    const newMedicine = new MedicineList(medicineData);
    await newMedicine.save();

    res.status(200).json({ message: 'MedicineList created successfully.' });
  } catch (error) {
    console.error('Error creating medicine:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.getMedicines = async (req, res) => {
  try {
    const medicines = await MedicineList.find();
    res.status(200).json(medicines);
  } catch (error) {
    console.error('Error fetching medicines:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};

exports.updateMedicine = async (req, res) => {
  const { id } = req.params;
  const updatedMedicineData = req.body;

  try {
    // Find the medicine by ID
    const existingMedicine = await MedicineList.findById(id);

    if (!existingMedicine) {
      return res.status(404).json({ error: 'MedicineList not found' });
    }

    // Update the medicine's data
    Object.assign(existingMedicine, updatedMedicineData);

    // Check if stock is below 50 and set stockalert property accordingly
    if (existingMedicine.stock < 50) {
      existingMedicine.stockalert = 'true';
      // Here, you can also send a message to the supplier
      // You can use a messaging service or send an email to the supplier
    } else {
      existingMedicine.stockalert = 'false';
    }

    // Save the updated medicine
    await existingMedicine.save();

    res.status(200).json({ message: 'MedicineList updated successfully.' });
  } catch (error) {
    console.error('Error updating medicine:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
