// controllers/addPatientDataController.js
const addPatientData = require('../models/AddpatientData');

exports.createaddPatientData = async (req, res) => {
  try {
    const addPatientData = new addPatientData(req.body);
    await addPatientData.save();
    res.status(201).json(addPatientData);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to add data' });
  }
};

exports.getaddPatientData = async (req, res) => {
  try {
    const { formType } = req.query;
    let query = {};

    if (formType) {
      query = { type: formType };
    }

    const data = await addPatientData.find(query);
    res.status(200).json(data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to fetch data' });
  }
};

exports.getaddPatientDataById = async (req, res) => {
  try {
    const { id } = req.params;
    console.log('Fetching Patient Details with ID:', id);

    const addPatientData = await addPatientData.findById(id);
    console.log('Fetched Patients Details:', addPatientData);

    if (!addPatientData) {
      return res.status(404).json({ error: 'Data not found' });
    }

    res.json(addPatientData);
  } catch (error) {
    console.error('Error fetching property:', error);
    res.status(500).json({ error: 'Internal server error.' });
  }
};
