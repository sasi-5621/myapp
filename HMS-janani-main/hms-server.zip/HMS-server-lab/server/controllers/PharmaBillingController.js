// controllers/pharmaBillingController.js
const PatientBill = require('../models/PharmaBillingModel');

exports.getPreviousBill = async (req, res) => {
  try {
    const previousBillData = await PatientBill.find({});
    res.status(200).json(previousBillData);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Unable to fetch previous bill data.' });
  }
};

exports.saveBillData = async (req, res) => {
  try {
    const PatientBillData = req.body;
    const newPatientBill = new PatientBill(PatientBillData);
    const savedPatientBill = await newPatientBill.save();
    res.status(200).json(savedPatientBill);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Unable to save PatientBill data.' });
  }
};
