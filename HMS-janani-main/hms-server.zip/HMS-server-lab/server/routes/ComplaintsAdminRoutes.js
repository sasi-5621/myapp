const express = require('express');
const router = express.Router();
const complaintsController = require('../controllers/ComplaintsAdminController');

// Create a new complaint
router.post('/complaints', complaintsController.createComplaint);

// Fetch all complaints
router.get('/complaints', complaintsController.getAllComplaints);

module.exports = router;
