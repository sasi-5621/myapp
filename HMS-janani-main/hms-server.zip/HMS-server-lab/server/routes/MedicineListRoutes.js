// routes/medicineRoutes.js
const express = require('express');
const router = express.Router();
const medicineController = require('../controllers/MedicineListController');

router.post('/createMedicine', medicineController.createMedicine);
router.get('/getMedicines', medicineController.getMedicines);
router.put('/updateMedicine/:id', medicineController.updateMedicine);

module.exports = router;
