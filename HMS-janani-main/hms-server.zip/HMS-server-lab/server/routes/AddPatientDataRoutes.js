// routes/addPatientDataRoutes.js
const express = require('express');
const router = express.Router();
const addPatientDataController = require('../controllers/AddpatientDataController');

router.post('/v1/combined-data', addPatientDataController.createaddPatientData);
router.get('/v1/combined-data', addPatientDataController.getaddPatientData);
router.get('/v1/combined-data/:id', addPatientDataController.getaddPatientDataById);

module.exports = router;
