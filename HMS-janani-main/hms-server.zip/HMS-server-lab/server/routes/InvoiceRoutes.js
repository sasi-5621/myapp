// routes/invoiceRoutes.js
const express = require('express');
const router = express.Router();
const invoiceController = require('../controllers/InvoiceController');

router.post('/addInvoice', invoiceController.addInvoice);
router.get('/getInvoice', invoiceController.getInvoice);
router.delete('/deleteInvoice/:id', invoiceController.deleteInvoice);

module.exports = router;
