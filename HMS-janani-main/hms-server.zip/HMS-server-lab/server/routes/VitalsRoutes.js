// routes/vitalsRoutes.js
const express = require('express');
const router = express.Router();
const vitalsController = require('../controllers/VitalsController');

router.post('/Vitalsdata', vitalsController.createVitals);
router.get('/Vitalsdata', vitalsController.getVitals);

module.exports = router;
