// routes/pharmaBillingRoutes.js
const express = require('express');
const router = express.Router();
const pharmaBillingController = require('../controllers/PharmaBillingController');

router.get('/getPreviousBill', pharmaBillingController.getPreviousBill);
router.post('/saveData', pharmaBillingController.saveBillData);

module.exports = router;
