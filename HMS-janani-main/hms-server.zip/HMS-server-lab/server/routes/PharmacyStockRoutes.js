const express = require('express');
const router = express.Router();
const pharmacyController = require('../controllers/PharmacyStockController');

// Define routes
router.put('/pharmacystockdata/:id', pharmacyController.updateProperty);
router.get('/pharmacystockdata', pharmacyController.getProperties);

module.exports = router;
