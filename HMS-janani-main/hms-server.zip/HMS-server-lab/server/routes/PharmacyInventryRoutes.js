// routes/pharmacyRoutes.js
const express = require('express');
const router = express.Router();
const pharmacyController = require('../controllers/PharmacyInventryController');

router.post('/inventorydata', pharmacyController.createInventoryItem);
router.get('/inventorydata', pharmacyController.getInventoryItems);
router.get('/inventorydata/expiry', pharmacyController.getExpiryInventoryItems);
router.get('/inventorydata/low', pharmacyController.getLowInventoryItems);
router.get('/inventorydata/zero', pharmacyController.getZeroInventoryItems);

module.exports = router;
