const express = require('express');
const router = express.Router();
const stockistController = require('../controllers/StockistController');

// Define routes
router.get('/stockists', stockistController.getStockists);
router.put('/stockists/:id', stockistController.updateStockist);

module.exports = router;
