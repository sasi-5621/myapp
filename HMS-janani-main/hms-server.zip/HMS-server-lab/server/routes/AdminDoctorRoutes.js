const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/AdminDoctorController');

// Route to get the count of registered doctors
router.get('/api/doctors/count', doctorController.getDoctorCount);

// Route to register a new doctor
router.post('/doctorregister', doctorController.registerDoctor);

// Route to get the largest doctor ID
router.get('/api/doctors/largest-id', doctorController.getLargestDoctorId);

// Route to get all doctors
router.get('/api/doctors', doctorController.getAllDoctors);

// Route to delete a doctor by ID
router.delete('/api/doctors/:id', doctorController.deleteDoctor);

module.exports = router;
