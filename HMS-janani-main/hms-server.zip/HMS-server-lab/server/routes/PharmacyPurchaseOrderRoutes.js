// routes/pharmacyRoutes.js
const express = require('express');
const router = express.Router();
const pharmacyController = require('../controllers/PharmacyPurchaseOrderController');

// Define your routes here
router.post('/addMedicine', pharmacyController.addMedicine);
router.post('/addCreatePurchaseOrder', pharmacyController.addCreatePurchaseOrder);
router.get('/getCreatePurchaseOrders', pharmacyController.getCreatePurchaseOrders);
router.put('/updateCreatePurchaseOrder/:id', pharmacyController.updateCreatePurchaseOrder);
router.delete('/deleteCreatePurchaseOrder/:id', pharmacyController.deleteCreatePurchaseOrder);

module.exports = router;
