const express = require('express');
const router = express.Router();
const staffController = require('../controllers/StaffAdminController');

// Route to get staff count by department
router.get('/GetStaffCount/:department', staffController.getStaffCount);

// Route to add staff
router.post('/Addstaff', staffController.addStaff);

// Route to fetch all staff data
router.get('/GetAllStaff', staffController.getAllStaff);

// Route to edit staff by ID
router.put('/EditStaff/:id', staffController.editStaff);

// Route to delete staff by ID
router.delete('/DeleteStaff/:id', staffController.deleteStaff);

// Route to get the next staff ID
router.get('/GetNextStaffId/:department', staffController.getNextStaffId);

module.exports = router;
