const express = require('express');
const router = express.Router();
const createPurchaseOrderController = require('../controllers/CreatePurchaseOrderController');

// Create a new purchase order
router.post('/', createPurchaseOrderController.createPurchaseOrder);

// Get all purchase orders
router.get('/', createPurchaseOrderController.getAllPurchaseOrders);

// Get purchase order by ID
router.get('/:id', createPurchaseOrderController.getPurchaseOrderById);

// Update purchase order by ID
router.put('/:id', createPurchaseOrderController.updatePurchaseOrderById);

// Delete purchase order by ID
router.delete('/:id', createPurchaseOrderController.deletePurchaseOrderById);

module.exports = router;
