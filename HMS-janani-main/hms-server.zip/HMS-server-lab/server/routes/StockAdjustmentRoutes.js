const express = require('express');
const router = express.Router();
const stockAdjustmentController = require('../controllers/StockAdjustmentController');

// Define routes
router.get('/stockadjustment', stockAdjustmentController.getStockAdjustmentData);

module.exports = router;
