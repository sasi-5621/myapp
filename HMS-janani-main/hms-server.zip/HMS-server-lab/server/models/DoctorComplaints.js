const mongoose = require('mongoose');

const doctorcomplaintsSchema = new mongoose.Schema({
  complaints: [String],
  diagnosis: [String],
  medicine: [String],
  advice: String,
  dietexercise: String,
  testsRequested: [String],
  testWhen: String,
  nextVisit: String,
  nextVisitType: String,
  nextVisitDate: String,
});

const DoctorComplaints = mongoose.model('DoctorComplaints', doctorcomplaintsSchema);

module.exports = DoctorComplaints;
