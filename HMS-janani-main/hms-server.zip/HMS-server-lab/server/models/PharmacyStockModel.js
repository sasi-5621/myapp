const mongoose = require('mongoose');

const pharmacySchema = new mongoose.Schema({
  fid: String,
  medName: String,
  invoice: String,
  batch: String,
  packPrice: String,
  packMRP: String,
  unitPrice: String,
  unitDiscount: String,
  UnitsInStock: String,
  expiryDate: String,
  packPricePercent: String,
  unitDiscountPercent: String,
});

module.exports = mongoose.model('Pharmacy', pharmacySchema);
