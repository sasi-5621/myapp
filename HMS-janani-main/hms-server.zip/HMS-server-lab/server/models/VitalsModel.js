// models/vitalsModel.js
const mongoose = require('mongoose');

const vitalsSchema = new mongoose.Schema({
  bp: String,
  sugar: String,
  height: String,
  weight: String,
  temperature: String,
  spo2: String,
  pallor: String,
  edema: String,
  lcterus: String,
  lymphadenopathy: String,
  ciubbing: String,
  cyanosis: String,
  jvp: String,
});

module.exports = mongoose.model('Vital', vitalsSchema);
