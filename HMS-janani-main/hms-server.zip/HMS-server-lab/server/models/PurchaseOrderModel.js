// models/purchaseOrderModel.js
const mongoose = require('mongoose');

const purchaseOrderSchema = new mongoose.Schema({
  id: Number,
  stockListName: String,
  date: String, // Changed the type to String
  Medicine: String,
  unitstrips: String,
  NoOfStrips: String,
  Edit: String,
});

module.exports = mongoose.model('CreatePurchaseOrder', purchaseOrderSchema);
