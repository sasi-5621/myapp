const mongoose = require('mongoose');

const stockAdjustmentSchema = new mongoose.Schema({
  madicinename: String,
  personname: String,
  gstNumber: String,
  time: String,
  beforestocks: String,
  afterstocks: Number,
  stockdifference: Number,
});

module.exports = mongoose.model('StockAdjustment', stockAdjustmentSchema);
