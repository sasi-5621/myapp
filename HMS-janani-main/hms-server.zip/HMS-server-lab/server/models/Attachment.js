// models/File.js
const mongoose = require('mongoose');

const attachmentSchema = new mongoose.Schema({
  filename: String,
  // Add more fields as needed
});

module.exports = mongoose.model('Attachement', attachmentSchema);
