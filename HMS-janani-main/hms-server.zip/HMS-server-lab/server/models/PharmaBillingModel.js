// models/pharmaBillingModel.js
const mongoose = require('mongoose');

const patientBillsSchema = new mongoose.Schema({
  name: String,
  gender: String,
  phone: String,
  email: String,
  referredDoctor: String,
  billdate: String,
  selectedPaymentMethod: String,
  gst: String,
  netAmount: String,
  roundOff: String,
  billAmount: String,
  paidAmount: String,
  reference: String,
  sales: [
    {
      medicineName: String,
      batch: String,
      price: String,
      quantity: String,
      discount: String,
      total: String,
      amount: String,
    },
  ],
});

module.exports = mongoose.model('PatientBill', patientBillsSchema);
