// models/invoiceModel.js
const mongoose = require('mongoose');

const invoiceSchema = new mongoose.Schema({
  invoiceNumber: String,
  stockName: String,
  date: String,
  Medicine: String,
  Batch: String,
  BatchExpiry: String,
  Unit: String,
  strips: String,
  Freestrips: String,
  Number: String,
  price: String,
  Gst: String,
  CGst: String,
  SGst: String,
  MRP: String,
  Total: String,
  isChecked: Boolean,
  HSNcode: String,
  RackNo: String,
  BookNo: String,
  NetPrice: String,
});

module.exports = mongoose.model('Invoice', invoiceSchema);
