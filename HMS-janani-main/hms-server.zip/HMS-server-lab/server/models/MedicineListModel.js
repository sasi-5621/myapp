// models/medicineModel.js
const mongoose = require('mongoose');

const medicineSchema = new mongoose.Schema({
  medid: String,
  medname: String,
  manufacturer: String,
  category: String,
  stock: Number,
  stockalert: String,
  edit: String,
});

module.exports = mongoose.model('MedicineList', medicineSchema);
