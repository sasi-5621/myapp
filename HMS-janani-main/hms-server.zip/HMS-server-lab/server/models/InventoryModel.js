// models/inventoryModel.js
const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
  medicinename: String,
  remainingunits: String,
  expirydate: Date,
});

module.exports = mongoose.model('Inventory', inventorySchema);
