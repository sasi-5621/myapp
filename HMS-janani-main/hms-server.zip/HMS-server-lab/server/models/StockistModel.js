const mongoose = require('mongoose');

const stockistSchema = new mongoose.Schema({
  name: String,
  gstNumber: String,
  email: String,
  addDate: String,
  totalBalance: Number,
  totalPaid: Number,
  balance: Number,
});

module.exports = mongoose.model('Stockist', stockistSchema);
