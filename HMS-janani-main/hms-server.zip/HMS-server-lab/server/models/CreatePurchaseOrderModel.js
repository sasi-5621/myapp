const mongoose = require('mongoose');

const createPurchaseOrderAdminSchema = new mongoose.Schema({
  id: Number,
  Date: String,
  Medicine: String,
  unitstrips: String,
  NoOfStrips: String,
  Edit: String,
});

const CreatePurchaseOrderAdmin = mongoose.model('CreatePurchaseOrderAdmin', createPurchaseOrderAdminSchema);

module.exports = CreatePurchaseOrderAdmin;
