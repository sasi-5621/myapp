// models/CombinedData.js
const mongoose = require('mongoose');

const itemSchema = new mongoose.Schema({
  type: String,
  price: String,
  discount: String,
});

const addPatientSchema = new mongoose.Schema({
    id: String,
    name: String,
    gender: String,
    age: Number,
    mobile: String,
    bloodGroup: String,
    email: String,
    address: String,
    city: String,
    area: String,
    referredBy: String,
    channel: String,
    items: [itemSchema],
    doctor: String,
    date: String,
    duration: String,
    hour: String,
    minute: String,
    timeOfDay: String,
    totalAmount: Number,
    paymentMode: String,
});

module.exports = mongoose.model('addPatientData', addPatientSchema);
